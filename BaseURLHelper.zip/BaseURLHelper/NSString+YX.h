//
//  NSString+YX.h
//  TRProject
//
//  Created by tarena on 16/7/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (YX)
@property (nonatomic, readonly) NSURL *yx_URL;

//特殊: 根据uid获取对应图片地址
@property (nonatomic, readonly) NSURL *yx_PtotoURL;
@end









