//
//  NetManager.m
//  TRProject
//
//  Created by tarena on 16/7/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "NetManager.h"

@implementation NetManager
/**
 *  头部banner
 */

//+ (id)getLAdBannerCompletionHandler:(void (^)(LAdModel *, NSError *))completionHandler
//{
//    NSString * urlPath = [NSString stringWithFormat:LAdBannerPath];
//    
//    return [self POST:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
//        !completionHandler ?: completionHandler([LAdModel parse:repsonseObj], error);
//    }];
//
//}
@end
