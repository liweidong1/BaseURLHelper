//
//  NSString+YX.m
//  TRProject
//
//  Created by tarena on 16/7/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "NSString+YX.h"

@implementation NSString (YX)
- (NSURL *)yx_URL{
    //http://  https://
    if ([self containsString:@"http://"] || [self containsString:@"https://"]) {
        return [NSURL URLWithString:self];
    }
    return [NSURL fileURLWithPath:self];
}

- (NSURL *)yx_PtotoURL
{
     return [NSString stringWithFormat:@"%@%@", LPhotoBasePath,self].yx_URL;
}


@end
